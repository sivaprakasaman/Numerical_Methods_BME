function [rnew]=ratecon(r,t)
rnew=-log(1-r)/t;
end
